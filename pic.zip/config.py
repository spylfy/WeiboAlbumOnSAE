#!/usr/bin/env python2.7
# coding: utf-8
# author: sandtears
# e-mail: me@sandtears.com


client_id = ''  # your AppKey
client_secret = ''  # your AppSecret
redirect_uri = ''  # must be same to your register redirect_uri
access_token = ''  # your access token
password = ''
params = {
    "access_token": access_token,
    "status": "Post Image...",
    "visible": 2
}  # upload params